/*
 * GABRIELLE MONTES DE OCA - Virtual Therapy Website
 * Design: Warm Botanical Sanctuary
 * All sections: Nav, Hero, Welcome, About, Specialties, Approach, Details, Contact, Footer
 */

import { useEffect, useState } from "react";
import logoIcon from "@/assets/logo-icon.png";
import heroBg from "@/assets/hero-bg.jpg";
import profilePhoto from "@/assets/profile-photo.jpg";

// Scroll Reveal Hook
function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

// Navigation
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <>
      <nav
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 1000,
          padding: scrolled ? "0.7rem 2rem" : "1rem 2rem",
          background: scrolled ? "rgba(245, 240, 235, 0.97)" : "transparent",
          backdropFilter: scrolled ? "blur(20px)" : "none",
          boxShadow: scrolled ? "0 2px 30px rgba(0,0,0,0.06)" : "none",
          transition: "all 0.4s ease",
        }}
      >
        <div
          style={{
            maxWidth: 1200,
            margin: "0 auto",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <a
            href="#hero"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "1.1rem",
              fontWeight: 600,
              color: "#3A3A3A",
              textDecoration: "none",
              letterSpacing: "0.5px",
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
            }}
          >
            <img
              src={logoIcon}
              alt="Gabrielle"
              style={{ width: 24, height: 24, objectFit: "contain" }}
            />
            Gabrielle Montes de Oca
          </a>

          {/* Desktop nav */}
          <ul
            style={{
              display: "flex",
              gap: "2rem",
              listStyle: "none",
              alignItems: "center",
              margin: 0,
              padding: 0,
            }}
            className="desktop-nav"
          >
            {[
              { id: "about", label: "About" },
              { id: "specialties", label: "Focus Areas" },
              { id: "approach", label: "Approach" },
              { id: "details", label: "Details" },
            ].map((item) => (
              <li key={item.id}>
                <a
                  href={`#${item.id}`}
                  style={{
                    textDecoration: "none",
                    color: "#3A3A3A",
                    fontSize: "0.82rem",
                    fontWeight: 400,
                    letterSpacing: "1px",
                    textTransform: "uppercase",
                    transition: "color 0.3s ease",
                    fontFamily: "'Montserrat', sans-serif",
                  }}
                  onMouseEnter={(e) =>
                    ((e.target as HTMLElement).style.color = "#9AAD88")
                  }
                  onMouseLeave={(e) =>
                    ((e.target as HTMLElement).style.color = "#3A3A3A")
                  }
                >
                  {item.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#contact"
                style={{
                  background: "#B7C4A7",
                  color: "#fff",
                  padding: "0.6rem 1.4rem",
                  borderRadius: 50,
                  fontSize: "0.8rem",
                  fontWeight: 500,
                  letterSpacing: "1px",
                  textTransform: "uppercase",
                  textDecoration: "none",
                  transition: "all 0.3s ease",
                  fontFamily: "'Montserrat', sans-serif",
                }}
                onMouseEnter={(e) => {
                  (e.target as HTMLElement).style.background = "#9AAD88";
                  (e.target as HTMLElement).style.transform = "translateY(-1px)";
                }}
                onMouseLeave={(e) => {
                  (e.target as HTMLElement).style.background = "#B7C4A7";
                  (e.target as HTMLElement).style.transform = "translateY(0)";
                }}
              >
                Contact & Book
              </a>
            </li>
          </ul>

          {/* Hamburger */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
            style={{
              display: "none",
              flexDirection: "column",
              gap: 5,
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: "4px",
              zIndex: 1001,
            }}
            className="hamburger-btn"
          >
            <span
              style={{
                width: 24,
                height: 2,
                background: "#3A3A3A",
                display: "block",
                transition: "all 0.3s ease",
                transform: menuOpen ? "rotate(45deg) translate(5px, 5px)" : "none",
              }}
            />
            <span
              style={{
                width: 24,
                height: 2,
                background: "#3A3A3A",
                display: "block",
                transition: "all 0.3s ease",
                opacity: menuOpen ? 0 : 1,
              }}
            />
            <span
              style={{
                width: 24,
                height: 2,
                background: "#3A3A3A",
                display: "block",
                transition: "all 0.3s ease",
                transform: menuOpen ? "rotate(-45deg) translate(5px, -5px)" : "none",
              }}
            />
          </button>
        </div>
      </nav>

      {/* Mobile overlay */}
      {menuOpen && (
        <div
          onClick={closeMenu}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.5)",
            zIndex: 998,
          }}
        />
      )}

      {/* Mobile menu */}
      <ul
        style={{
          position: "fixed",
          top: 0,
          right: menuOpen ? 0 : "-100%",
          width: 280,
          height: "100vh",
          background: "#FAF7F4",
          flexDirection: "column",
          padding: "5rem 2rem",
          transition: "right 0.3s ease",
          zIndex: 999,
          listStyle: "none",
          margin: 0,
          display: "flex",
          gap: "1.5rem",
        }}
      >
        {[
          { id: "about", label: "About" },
          { id: "specialties", label: "Focus Areas" },
          { id: "approach", label: "Approach" },
          { id: "details", label: "Details" },
          { id: "contact", label: "Contact & Book" },
        ].map((item) => (
          <li key={item.id}>
            <a
              href={`#${item.id}`}
              onClick={closeMenu}
              style={{
                textDecoration: "none",
                color: "#3A3A3A",
                fontSize: "1rem",
                fontWeight: 400,
                letterSpacing: "1px",
                textTransform: "uppercase",
                fontFamily: "'Montserrat', sans-serif",
              }}
            >
              {item.label}
            </a>
          </li>
        ))}
      </ul>

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .hamburger-btn { display: flex !important; }
        }
      `}</style>
    </>
  );
}

// Hero Section
function Hero() {
  return (
    <section
      id="hero"
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        overflow: "hidden",
        background:
          "linear-gradient(135deg, #E8E0D8 0%, #D4C8BC 30%, #C5CFC0 70%, #B7C4A7 100%)",
      }}
    >
      {/* Background image */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `url(${heroBg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.35,
        }}
      />
      {/* Gradient overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse at 20% 50%, rgba(197,207,192,0.4) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(245,240,235,0.5) 0%, transparent 50%), rgba(245,240,235,0.3)",
        }}
      />
      {/* Decorative rings */}
      <div
        style={{
          position: "absolute",
          width: 600,
          height: 600,
          border: "1px solid #9AAD88",
          borderRadius: "50%",
          opacity: 0.08,
          top: -100,
          right: -150,
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 400,
          height: 400,
          border: "1px solid #9AAD88",
          borderRadius: "50%",
          opacity: 0.08,
          bottom: -50,
          left: -100,
          pointerEvents: "none",
        }}
      />

      {/* Content */}
      <div
        style={{
          position: "relative",
          zIndex: 1,
          textAlign: "center",
          padding: "2rem",
          maxWidth: 800,
          marginTop: "2rem",
        }}
      >
        <span
          style={{
            display: "inline-block",
            fontSize: "0.75rem",
            letterSpacing: 3,
            textTransform: "uppercase",
            color: "#5A5A5A",
            marginBottom: "2rem",
            opacity: 0,
            animation: "fadeInUp 1s ease 0.3s forwards",
            fontFamily: "'Montserrat', sans-serif",
          }}
        >
          Therapy · Growth · Healing
        </span>

        <h1
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(2.5rem, 5vw, 4rem)",
            fontWeight: 500,
            color: "#3A3A3A",
            lineHeight: 1.2,
            marginBottom: "1.5rem",
            opacity: 0,
            animation: "fadeInUp 1s ease 0.5s forwards",
          }}
        >
          Gabrielle Montes de Oca
          <br />
          MSW, RCSWI
        </h1>

        <p
          style={{
            fontSize: "clamp(1.05rem, 2vw, 1.25rem)",
            color: "#5A5A5A",
            fontWeight: 300,
            marginBottom: "1rem",
            fontStyle: "italic",
            fontFamily: "'Playfair Display', serif",
            opacity: 0,
            animation: "fadeInUp 1s ease 0.7s forwards",
          }}
        >
          Where healing is guided through understanding and compassion. Where you are witnessed, honored, and held in your becoming.
        </p>

        <p
          style={{
            fontSize: "0.85rem",
            color: "#5A5A5A",
            letterSpacing: 2,
            textTransform: "uppercase",
            marginBottom: "2.5rem",
            opacity: 0,
            animation: "fadeInUp 1s ease 0.9s forwards",
            fontFamily: "'Montserrat', sans-serif",
          }}
        >
          100% Virtual Sessions <span style={{ opacity: 0.4, margin: "0 0.5rem" }}>·</span> Based in Florida
        </p>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            flexWrap: "wrap",
            gap: "10px",
            opacity: 0,
            animation: "fadeInUp 1s ease 1.1s forwards",
          }}
        >
          <a
            href="#contact"
            style={{
              display: "inline-block",
              background: "#C4956A",
              color: "#fff",
              padding: "1rem 2.5rem",
              borderRadius: 50,
              textDecoration: "none",
              fontSize: "0.85rem",
              fontWeight: 500,
              letterSpacing: 2,
              textTransform: "uppercase",
              transition: "all 0.4s ease",
              boxShadow: "0 4px 20px rgba(196,149,106,0.3)",
              fontFamily: "'Montserrat', sans-serif",
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget;
              el.style.background = "#B07D52";
              el.style.transform = "translateY(-2px)";
              el.style.boxShadow = "0 8px 30px rgba(196,149,106,0.4)";
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget;
              el.style.background = "#C4956A";
              el.style.transform = "translateY(0)";
              el.style.boxShadow = "0 4px 20px rgba(196,149,106,0.3)";
            }}
          >
            Message for Discovery Call
          </a>
          <a
            href="https://gabriellem.sessionshealth.com/"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "inline-block",
              background: "transparent",
              border: "1.5px solid #C4956A",
              color: "#C4956A",
              padding: "1rem 2.5rem",
              borderRadius: 50,
              textDecoration: "none",
              fontSize: "0.85rem",
              fontWeight: 500,
              letterSpacing: 2,
              textTransform: "uppercase",
              transition: "all 0.4s ease",
              fontFamily: "'Montserrat', sans-serif",
            }}
            onMouseEnter={(e) => {
              const el = e.currentTarget;
              el.style.background = "#C4956A";
              el.style.color = "#fff";
            }}
            onMouseLeave={(e) => {
              const el = e.currentTarget;
              el.style.background = "transparent";
              el.style.color = "#C4956A";
            }}
          >
            Client Portal
          </a>
        </div>
      </div>

      <style>{`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(25px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </section>
  );
}

// Welcome Section
function Welcome() {
  return (
    <section
      id="welcome"
      style={{ background: "#FAF7F4", padding: "6rem 2rem" }}
    >
      <div style={{ maxWidth: 750, margin: "0 auto", textAlign: "center" }}>
        <h2
          className="reveal"
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "clamp(1.8rem, 3vw, 2.5rem)",
            fontWeight: 500,
            color: "#9AAD88",
            marginBottom: "1rem",
            fontStyle: "italic",
          }}
        >
          "The curious paradox is that when I accept myself just as I am, then I can change."
        </h2>
        <p
          className="reveal"
          style={{
            fontSize: "0.9rem",
            textTransform: "uppercase",
            letterSpacing: 2,
            color: "#5A5A5A",
            marginBottom: "2rem",
            fontFamily: "'Montserrat', sans-serif",
          }}
        >
          — Carl Rogers
        </p>
        <div
          className="reveal"
          style={{
            width: 60,
            height: 1.5,
            background: "#B7C4A7",
            margin: "0 auto 2rem",
          }}
        />
        <span
          className="reveal"
          style={{
            display: "block",
            margin: "0 auto 2rem",
            fontSize: "1.5rem",
            opacity: 0.4,
          }}
        >
          🌿
        </span>
        <p
          className="reveal reveal-delay-1"
          style={{
            fontSize: "1.05rem",
            color: "#5A5A5A",
            lineHeight: 1.9,
            marginBottom: "1.5rem",
            fontWeight: 300,
          }}
        >
          Maybe you've been carrying something heavy for a long time. Maybe you're navigating a transition that feels overwhelming, or you just know that something feels off — and you're ready to explore what that is.
        </p>
        <p
          className="reveal reveal-delay-2"
          style={{
            fontSize: "1.05rem",
            color: "#5A5A5A",
            lineHeight: 1.9,
            fontWeight: 300,
          }}
        >
          Therapy is not about fixing what's broken. It's about creating space — space to breathe, to process, to grow, and to reconnect with yourself.
        </p>
      </div>
    </section>
  );
}

// About Section
function About() {
  return (
    <section
      id="about"
      style={{ background: "#EDF1E9", padding: "6rem 2rem" }}
    >
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1.3fr",
            gap: "4rem",
            alignItems: "center",
          }}
          className="about-grid"
        >
          {/* Portrait */}
          <div
            className="reveal"
            style={{
              borderRadius: 12,
              overflow: "hidden",
              aspectRatio: "3/4",
              background:
                "linear-gradient(135deg, #C5CFC0 0%, #F0E4DA 100%)",
              position: "relative",
            }}
          >
            <img
              src={profilePhoto}
              alt="Gabrielle Montes de Oca"
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                display: "block",
              }}
            />
          </div>

          {/* Text */}
          <div>
            <span
              className="reveal"
              style={{
                display: "block",
                fontSize: "0.75rem",
                letterSpacing: 3,
                textTransform: "uppercase",
                color: "#9AAD88",
                marginBottom: "0.8rem",
                fontFamily: "'Montserrat', sans-serif",
                fontWeight: 500,
              }}
            >
              About Me
            </span>
            <h2
              className="reveal"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(1.8rem, 3vw, 2.5rem)",
                fontWeight: 500,
                color: "#3A3A3A",
                marginBottom: "1.5rem",
              }}
            >
              Hi, I'm Gabrielle.
            </h2>
            <p
              className="reveal"
              style={{
                fontSize: "0.95rem",
                color: "#5A5A5A",
                lineHeight: 1.85,
                marginBottom: "1.2rem",
                fontWeight: 300,
              }}
            >
              I'm a Registered Clinical Social Work Intern based in Florida, providing virtual therapy to residents across the state. I work with individuals navigating complex trauma, anxiety, depression, relationship issues, and the unique lived experiences of the BIPOC and LGBTQ community. I approach each session with humility, curiosity, and genuine care.
            </p>
            <p
              className="reveal"
              style={{
                fontSize: "0.95rem",
                color: "#5A5A5A",
                lineHeight: 1.85,
                marginBottom: "1.5rem",
                fontWeight: 300,
              }}
            >
              My goal is to create a nonjudgmental, compassionate space where you can show up exactly as you are. We'll work collaboratively to understand your past, honor your present, and build the tools you need for the future.
            </p>
            <ul
              className="reveal"
              style={{
                listStyle: "none",
                padding: 0,
                margin: "0 0 2rem",
              }}
            >
              {[
                "Master of Social Work, Florida International University",
                "Registered Clinical Social Work Intern #ISW 21100, State of Florida",
              ].map((item) => (
                <li
                  key={item}
                  style={{
                    position: "relative",
                    paddingLeft: "1.5rem",
                    marginBottom: "0.6rem",
                    fontSize: "0.9rem",
                    color: "#5A5A5A",
                    fontWeight: 300,
                  }}
                >
                  <span
                    style={{
                      position: "absolute",
                      left: 0,
                      top: 10,
                      width: 6,
                      height: 6,
                      borderRadius: "50%",
                      background: "#B7C4A7",
                      display: "inline-block",
                    }}
                  />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <style>{`
        @media (max-width: 768px) {
          .about-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}

// Specialties Section
const specialties = [
  {
    icon: "🌿",
    title: "Complex Trauma",
    desc: "Processing long-term emotional wounds, childhood trauma, and finding safety in your mind and body again.",
  },
  {
    icon: "🌧",
    title: "Anxiety & Depression",
    desc: "Navigating racing thoughts, persistent worry, low mood, numbness, or feeling disconnected from joy.",
  },
  {
    icon: "🕊",
    title: "Grief & Loss",
    desc: "Honoring and processing loss of all kinds: people, relationships, versions of yourself, or expectations.",
  },
  {
    icon: "🌟",
    title: "Life Experiences & Complexity",
    desc: "Witnessing and holding space as you navigate the intricate dimensions of your life: relationships, identity, transitions, and the profound questions that shape who you are.",
  },
];

function Specialties() {
  return (
    <section
      id="specialties"
      style={{ background: "#FAF7F4", padding: "6rem 2rem" }}
    >
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <p
            className="reveal"
            style={{
              fontSize: "0.75rem",
              letterSpacing: 3,
              textTransform: "uppercase",
              color: "#9AAD88",
              marginBottom: "1rem",
              fontWeight: 500,
              fontFamily: "'Montserrat', sans-serif",
            }}
          >
            Areas of Focus
          </p>
          <h2
            className="reveal"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.8rem)",
              fontWeight: 500,
              color: "#3A3A3A",
            }}
          >
            What I Help With
          </h2>
          <div
            className="reveal"
            style={{
              width: 60,
              height: 1.5,
              background: "#B7C4A7",
              margin: "1.5rem auto 0",
            }}
          />
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "2rem",
            maxWidth: 900,
            margin: "0 auto",
          }}
          className="specialties-grid"
        >
          {specialties.map((s, i) => (
            <SpecialtyCard key={s.title} {...s} delay={i % 2} />
          ))}
        </div>
      </div>
      <style>{`
        @media (max-width: 768px) {
          .specialties-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}

function SpecialtyCard({
  icon,
  title,
  desc,
  delay,
}: {
  icon: string;
  title: string;
  desc: string;
  delay: number;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      className={`reveal${delay > 0 ? " reveal-delay-1" : ""}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: "#fff",
        padding: "2.5rem 2rem",
        borderRadius: 12,
        border: "1px solid rgba(183,196,167,0.2)",
        position: "relative",
        overflow: "hidden",
        transition: "all 0.4s ease",
        transform: hovered ? "translateY(-4px)" : "translateY(0)",
        boxShadow: hovered
          ? "0 12px 40px rgba(0,0,0,0.06)"
          : "0 2px 8px rgba(0,0,0,0.02)",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: 3,
          background: "#B7C4A7",
          transform: hovered ? "scaleX(1)" : "scaleX(0)",
          transition: "transform 0.4s ease",
          transformOrigin: "left",
        }}
      />
      <span style={{ fontSize: "2rem", marginBottom: "1.2rem", display: "block" }}>
        {icon}
      </span>
      <h3
        style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "1.2rem",
          fontWeight: 500,
          color: "#3A3A3A",
          marginBottom: "0.8rem",
        }}
      >
        {title}
      </h3>
      <p
        style={{
          fontSize: "0.9rem",
          color: "#5A5A5A",
          lineHeight: 1.7,
          fontWeight: 300,
        }}
      >
        {desc}
      </p>
    </div>
  );
}

// Approach Section
const approachItems = [
  {
    icon: "🌱",
    title: "A relationship built on trust and understanding.",
    desc: "Everything starts with safety. I will never push you faster than you are ready to go. The therapeutic relationship is a collaborative partnership.",
  },
  {
    icon: "💡",
    title: "Evidence-based methods.",
    desc: "I draw from Cognitive Behavioral Therapy (CBT), Dialectical Behavior Therapy (DBT), Narrative Therapy, and Attachment theory. Always tailored to what works best for you and your unique experiences.",
  },
  {
    icon: "📖",
    title: "Story-telling.",
    desc: "Your story matters. Through gentle exploration of your experiences, we uncover patterns, build understanding, and create new narratives that honor your resilience and growth.",
  },
];

function Approach() {
  return (
    <section
      id="approach"
      style={{ background: "#F5F0EB", padding: "6rem 2rem" }}
    >
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <p
            className="reveal"
            style={{
              fontSize: "0.75rem",
              letterSpacing: 3,
              textTransform: "uppercase",
              color: "#9AAD88",
              marginBottom: "1rem",
              fontWeight: 500,
              fontFamily: "'Montserrat', sans-serif",
            }}
          >
            Philosophy
          </p>
          <h2
            className="reveal"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.8rem)",
              fontWeight: 500,
              color: "#3A3A3A",
            }}
          >
            My Approach
          </h2>
          <div
            className="reveal"
            style={{
              width: 60,
              height: 1.5,
              background: "#B7C4A7",
              margin: "1.5rem auto 0",
            }}
          />
        </div>

        <div style={{ maxWidth: 750, margin: "0 auto" }}>
          {approachItems.map((item, i) => (
            <div
              key={item.title}
              className={`reveal${i > 0 ? " reveal-delay-1" : ""}`}
              style={{
                display: "flex",
                gap: "2rem",
                marginBottom: "2.5rem",
                paddingBottom: "2.5rem",
                borderBottom:
                  i < approachItems.length - 1
                    ? "1px solid rgba(183,196,167,0.2)"
                    : "none",
                alignItems: "flex-start",
              }}
            >
              <div
                style={{
                  flexShrink: 0,
                  width: 50,
                  height: 50,
                  background: "#EDF1E9",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "1.2rem",
                }}
              >
                {item.icon}
              </div>
              <div>
                <h3
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: "1.2rem",
                    fontWeight: 500,
                    color: "#3A3A3A",
                    marginBottom: "0.5rem",
                  }}
                >
                  {item.title}
                </h3>
                <p
                  style={{
                    fontSize: "0.95rem",
                    color: "#5A5A5A",
                    lineHeight: 1.75,
                    fontWeight: 300,
                  }}
                >
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Details Section
function Details() {
  return (
    <section id="details" style={{ background: "#EDF1E9", padding: "6rem 2rem" }}>
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "4rem" }}>
          <p
            className="reveal"
            style={{
              fontSize: "0.75rem",
              letterSpacing: 3,
              textTransform: "uppercase",
              color: "#9AAD88",
              marginBottom: "1rem",
              fontWeight: 500,
              fontFamily: "'Montserrat', sans-serif",
            }}
          >
            Logistics
          </p>
          <h2
            className="reveal"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.8rem)",
              fontWeight: 500,
              color: "#3A3A3A",
            }}
          >
            Practice Details
          </h2>
          <div
            className="reveal"
            style={{
              width: 60,
              height: 1.5,
              background: "#B7C4A7",
              margin: "1.5rem auto 0",
            }}
          />
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "1.5rem",
            maxWidth: 900,
            margin: "0 auto",
          }}
          className="details-grid"
        >
          {[
            { title: "Location & Format", info: "100% Virtual Sessions. Available to all residents residing in the state of Florida." },
            { title: "Session Fee", info: "$60 per session. Cash or card payments only. I do not accept insurance." },
            { title: "Hours of Operation", info: "Tuesdays & Thursdays: 6:00 P.M. – 8:00 P.M.\nSaturdays: 10:00 A.M. – 6:00 P.M." },
            { title: "Booking & Portal", info: "Current clients can manage their portal and book sessions independently via Sessions Health." },
          ].map((d, i) => (
            <div
              key={d.title}
              className={`reveal${i > 1 ? " reveal-delay-1" : ""}`}
              style={{
                background: "#fff",
                padding: "1.8rem 2rem",
                borderRadius: 10,
                borderLeft: "3px solid #B7C4A7",
              }}
            >
              <h4
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "1rem",
                  fontWeight: 500,
                  color: "#3A3A3A",
                  marginBottom: "0.4rem",
                }}
              >
                {d.title}
              </h4>
              <p
                style={{
                  fontSize: "0.9rem",
                  color: "#5A5A5A",
                  fontWeight: 300,
                  whiteSpace: "pre-line",
                }}
              >
                {d.info}
              </p>
            </div>
          ))}
        </div>
      </div>
      <style>{`
        @media (max-width: 768px) {
          .details-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
}

// FAQ Section
function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      q: "How long is each therapy session?",
      a: "Sessions are 50 minutes long. This allows time for meaningful work while respecting your schedule. The first session may include additional intake paperwork.",
    },
    {
      q: "What is your cancellation policy?",
      a: "I request at least 24 hours notice for cancellations or rescheduling. Cancellations made with less than 24 hours notice may be subject to a cancellation fee. Life happens, so please reach out if you need to reschedule.",
    },
    {
      q: "What should I expect during my first session?",
      a: "Our first session is an opportunity to get to know each other and explore whether we're a good fit. We'll discuss what brings you to therapy, your goals, and my approach. You'll have time to ask questions, and there's no pressure to dive into deep work right away.",
    },
    {
      q: "How often should I come to therapy?",
      a: "Frequency depends on your needs and goals. Many clients find weekly sessions helpful for building momentum, while others prefer bi-weekly sessions. We'll discuss what works best for you during our first meeting.",
    },
    {
      q: "Do you accept insurance?",
      a: "I operate on a private pay basis at this time. Sessions are $60 per session, payable by cash or card. I can provide you with a receipt for potential insurance reimbursement if your plan covers out-of-network providers.",
    },
    {
      q: "Is everything I share confidential?",
      a: "Yes, with few exceptions. Confidentiality is a cornerstone of therapy. There are legal limits to confidentiality in cases of imminent danger, abuse, or court-ordered disclosure. I'll discuss these limits with you during our first session.",
    },
  ];

  return (
    <section
      id="faq"
      style={{ background: "#fff", padding: "6rem 2rem" }}
    >
      <div style={{ maxWidth: 900, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "3rem" }}>
          <p
            className="reveal"
            style={{
              fontSize: "0.75rem",
              letterSpacing: 3,
              textTransform: "uppercase",
              color: "#9AAD88",
              marginBottom: "1rem",
              fontWeight: 500,
              fontFamily: "'Montserrat', sans-serif",
            }}
          >
            Questions
          </p>
          <h2
            className="reveal"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.8rem)",
              fontWeight: 500,
              color: "#3A3A3A",
              marginBottom: "1rem",
            }}
          >
            Frequently Asked Questions
          </h2>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="reveal"
              style={{
                border: "1px solid rgba(183,196,167,0.2)",
                borderRadius: 8,
                overflow: "hidden",
                transition: "all 0.3s ease",
              }}
            >
              <button
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                style={{
                  width: "100%",
                  padding: "1.5rem",
                  background: openIndex === idx ? "#EDF1E9" : "#fff",
                  border: "none",
                  textAlign: "left",
                  cursor: "pointer",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  transition: "background 0.3s ease",
                  fontFamily: "'Montserrat', sans-serif",
                }}
                onMouseEnter={(e) => {
                  if (openIndex !== idx) {
                    (e.currentTarget).style.background = "#FAF7F4";
                  }
                }}
                onMouseLeave={(e) => {
                  if (openIndex !== idx) {
                    (e.currentTarget).style.background = "#fff";
                  }
                }}
              >
                <span
                  style={{
                    fontSize: "1rem",
                    fontWeight: 500,
                    color: "#3A3A3A",
                  }}
                >
                  {faq.q}
                </span>
                <span
                  style={{
                    fontSize: "1.2rem",
                    color: "#9AAD88",
                    transition: "transform 0.3s ease",
                    transform: openIndex === idx ? "rotate(180deg)" : "rotate(0deg)",
                  }}
                >
                  ▼
                </span>
              </button>
              {openIndex === idx && (
                <div
                  style={{
                    padding: "2rem 1.5rem",
                    background: "#FAF7F4",
                    borderTop: "1px solid rgba(183,196,167,0.2)",
                    fontSize: "0.95rem",
                    color: "#5A5A5A",
                    fontWeight: 300,
                    lineHeight: 1.8,
                  }}
                >
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Contact Section
function Contact() {
  return (
    <section
      id="contact"
      style={{ background: "#FAF7F4", padding: "6rem 2rem" }}
    >
      <div style={{ maxWidth: 1100, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: "3rem" }}>
          <p
            className="reveal"
            style={{
              fontSize: "0.75rem",
              letterSpacing: 3,
              textTransform: "uppercase",
              color: "#9AAD88",
              marginBottom: "1rem",
              fontWeight: 500,
              fontFamily: "'Montserrat', sans-serif",
            }}
          >
            Reach Out
          </p>
          <h2
            className="reveal"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.8rem)",
              fontWeight: 500,
              color: "#3A3A3A",
            }}
          >
            Contact & Book
          </h2>
          <div
            className="reveal"
            style={{
              width: 60,
              height: 1.5,
              background: "#B7C4A7",
              margin: "1.5rem auto 0",
            }}
          />
        </div>

        <div
          style={{
            maxWidth: 700,
            margin: "0 auto",
            background: "#fff",
            padding: "3rem",
            borderRadius: 12,
            border: "1px solid rgba(183,196,167,0.2)",
            textAlign: "center",
          }}
          className="reveal"
        >
          <h3
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "1.5rem",
              color: "#3A3A3A",
              marginBottom: "1rem",
            }}
          >
            Ready to begin?
          </h3>
          <p
            style={{
              fontSize: "0.95rem",
              color: "#5A5A5A",
              marginBottom: "1.5rem",
              fontWeight: 300,
              lineHeight: 1.8,
            }}
          >
            To protect your privacy and ensure HIPAA compliance, all bookings and communications happen through my secure therapy portal. Whether you're a returning client or interested in scheduling a discovery call, please use the portal below.
          </p>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "1rem",
              marginTop: "2rem",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.8rem",
                fontSize: "0.9rem",
                color: "#5A5A5A",
                justifyContent: "center",
              }}
            >
              <div
                style={{
                  width: 36,
                  height: 36,
                  background: "#EDF1E9",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "1rem",
                  flexShrink: 0,
                }}
              >
                💻
              </div>
              <span>Virtual Therapy via Secure Video</span>
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.8rem",
                fontSize: "0.9rem",
                color: "#5A5A5A",
                justifyContent: "center",
              }}
            >
              <div
                style={{
                  width: 36,
                  height: 36,
                  background: "#EDF1E9",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: "1rem",
                  flexShrink: 0,
                }}
              >
                💳
              </div>
              <span>$60 / Session (Cash or Card)</span>
            </div>
          </div>

          <a
            href="https://gabriellem.sessionshealth.com/"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "inline-block",
              background: "#C4956A",
              color: "#fff",
              padding: "1rem 2.5rem",
              borderRadius: 50,
              textDecoration: "none",
              fontSize: "0.85rem",
              fontWeight: 500,
              letterSpacing: 1,
              textTransform: "uppercase",
              marginTop: "2rem",
              transition: "background 0.3s",
              fontFamily: "'Montserrat', sans-serif",
            }}
            onMouseEnter={(e) =>
              ((e.currentTarget).style.background = "#B07D52")
            }
            onMouseLeave={(e) =>
              ((e.currentTarget).style.background = "#C4956A")
            }
          >
            Access Client Portal
          </a>
        </div>
      </div>

    </section>
  );
}

// Footer
function Footer() {
  return (
    <footer
      style={{
        background: "#3A3A3A",
        color: "rgba(245,240,235,0.6)",
        padding: "3rem 2rem",
        textAlign: "center",
      }}
    >
      <div
        style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "1.3rem",
          color: "#F5F0EB",
          marginBottom: "0.5rem",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: "0.5rem",
        }}
      >
        <img
          src={logoIcon}
          alt=""
          style={{ width: 24, height: 24, objectFit: "contain", opacity: 0.8 }}
        />
        Gabrielle Montes de Oca, MSW, RCSWI
      </div>
      <p style={{ fontSize: "0.85rem", marginBottom: "1.5rem" }}>
        Florida Virtual Therapy
      </p>
      <p style={{ fontSize: "0.8rem", opacity: 0.6, lineHeight: 1.8 }}>
        © {new Date().getFullYear()} Raiz and Shine Therapy LLC. All rights
        reserved.
        <br />
        <br />
        If you are in crisis, please call{" "}
        <a href="tel:988" style={{ color: "#B7C4A7" }}>
          988
        </a>{" "}
        (Suicide & Crisis Lifeline) or go to your nearest emergency room.
      </p>
    </footer>
  );
}

// Main Page
export default function Home() {
  useScrollReveal();

  return (
    <div style={{ minHeight: "100vh" }}>
      <Navbar />
      <Hero />
      <Welcome />
      <About />
      <Specialties />
      <Approach />
      <Details />
      <FAQ />
      <Contact />
      <Footer />
    </div>
  );
}
