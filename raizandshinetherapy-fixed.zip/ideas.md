# The Inner Room Therapy — Design Ideas

## Three Stylistic Approaches

### 1. Warm Botanical Sanctuary
**Theme:** Organic warmth meets quiet luxury — like stepping into a sun-lit greenhouse.
**Probability:** 0.07

### 2. Soft Minimalist Refuge
**Theme:** Japanese-inspired negative space with warm ivory and sage — stillness as a design principle.
**Probability:** 0.06

### 3. Earthy Editorial
**Theme:** Magazine-quality editorial layout with earthy terracotta and sage, asymmetric columns, and expressive serif typography.
**Probability:** 0.09

---

## Chosen Approach: **Warm Botanical Sanctuary** (Approach 1)

### Design Movement
Organic Modernism — the intersection of natural warmth, editorial typography, and quiet luxury. Inspired by Kinfolk magazine and high-end wellness brands.

### Core Principles
1. **Warmth over sterility** — every color, texture, and spacing choice evokes comfort and safety
2. **Typography as atmosphere** — Playfair Display for emotional resonance, Montserrat for grounded clarity
3. **Breathing room** — generous whitespace signals unhurried attention, mirroring the therapy experience
4. **Subtle organic motion** — gentle fade-ins and scroll reveals, never jarring

### Color Philosophy
- **Ivory (#F5F0EB)** — the base, warm not cold, like parchment in afternoon light
- **Sage (#B7C4A7)** — trust, growth, the natural world; primary accent
- **Terracotta (#C4956A)** — warmth, grounding, call-to-action energy
- **Charcoal (#3A3A3A)** — readable, human, not harsh black
- Emotional intent: the palette should feel like a warm room with plants, soft light, and linen

### Layout Paradigm
Asymmetric editorial flow — hero is full-bleed centered, but content sections alternate between left-heavy and right-heavy grids. About section uses a 2-column portrait+text split. No rigid symmetry.

### Signature Elements
1. **Thin sage divider lines** — used sparingly to separate content, like a breath between thoughts
2. **Circular decorative rings** — subtle, low-opacity circles in hero as organic decoration
3. **Leaf motif (🌿)** — used as a gentle accent throughout, never overused

### Interaction Philosophy
Interactions should feel like a slow exhale — smooth, unhurried. Hover states are gentle color shifts, not dramatic transforms. Scroll animations reveal content like turning a page.

### Animation
- Entrance: `fadeInUp` with staggered delays (0.1s per item)
- Scroll reveals: `IntersectionObserver` with 0.8s cubic-bezier ease
- FAQ accordion: smooth max-height transition
- Nav: transparent → frosted glass on scroll
- All under 400ms for UI interactions

### Typography System
- **Display:** Playfair Display (serif) — headlines, section titles, blockquotes
- **Body:** Montserrat (sans-serif) — body text, labels, navigation
- **Hierarchy:** Display 400/500/600 for headings, Montserrat 300 for body, 500 for CTAs

### Brand Essence
*A licensed therapist's digital sanctuary — for adults ready to begin the work of healing, offered with warmth and without judgment.*
**Personality:** Warm · Grounded · Trustworthy

### Brand Voice
Headlines sound like a gentle invitation, not a sales pitch.
- "You don't have to have it all figured out to start."
- "A safe space to be seen, heard, and held."
No filler phrases like "Welcome to our website" or "Get started today."

### Wordmark & Logo
A simple leaf-in-circle mark — a single sage-colored botanical leaf enclosed in a thin circle, suggesting both nature and a contained, safe space.

### Signature Brand Color
**Sage (#B7C4A7)** — the unmistakable color of this brand, used in dividers, accents, and the nav CTA.
